/**
 * GEO 功能前端卡片化的统一 API 封装。
 * 全部请求走 yayu BFF 的 /api/geo/api/v1（本地 controller：数据存 BFF 个人空间，计算转发 :3002）。
 * 返回结构统一为 { ok, data, error }，这里剥壳后直接返回 data。
 */

import { getAuthToken } from '../api/session'

let geoApiBase = '/api/geo/api/v1'
let productSessionToken: string | null = null
let onProductSessionExpired: (() => void) | null = null

/**
 * 独立 GEO Product 的 Host 注入面。
 *
 * yayu 旧会话页不调用它，继续走原 BFF 与自身登录 token；独立 Product 页面在收到
 * `eios.product_host/v1` 的 host.session 后调用它，改走 EIOS 的单一产品门。
 */
export function configureGeoProductTransport(options: {
  apiBase: string
  sessionToken: string | null
  onSessionExpired?: () => void
}) {
  geoApiBase = options.apiBase.replace(/\/+$/, '')
  productSessionToken = options.sessionToken
  onProductSessionExpired = options.onSessionExpired ?? null
}

function geoHeaders(): Record<string, string> {
  const headers: Record<string, string> = { 'Content-Type': 'application/json' }
  const token = productSessionToken ?? getAuthToken()
  if (token) headers.Authorization = `Bearer ${token}`
  return headers
}

const NEST_GENERIC = /^(Bad Request|Internal Server Error|Unauthorized|Forbidden|Not Found)$/i

/** 页面可以据此决定展示重试、去配置还是联系管理员。保持 Error 兼容，旧卡片无需改造即可使用。 */
export type GeoErrorCode = 'empty' | 'not-configured' | 'forbidden' | 'not-found' | 'upstream' | 'contract'

export class GeoApiError extends Error {
  readonly name = 'GeoApiError'
  readonly code: GeoErrorCode
  readonly status: number
  readonly jobId?: string
  readonly jobStatus?: string

  constructor(message: string, options: { code: GeoErrorCode; status: number; jobId?: string; jobStatus?: string }) {
    super(message)
    this.code = options.code
    this.status = options.status
    this.jobId = options.jobId
    this.jobStatus = options.jobStatus
  }
}

export type GeoErrorBody = { error?: unknown; detail?: unknown; message?: unknown; statusCode?: unknown; code?: unknown; error_code?: unknown; job_id?: unknown; jobId?: unknown; status?: unknown }

function bodyCode(j: GeoErrorBody | null): string {
  const candidates = [j?.code, j?.error_code, j?.error, j?.message]
  for (const value of candidates) {
    if (typeof value === 'string' && value.trim()) return value.trim().toLowerCase()
    if (value && typeof value === 'object') {
      const nested = value as { code?: unknown; message?: unknown; error?: unknown }
      if (typeof nested.code === 'string') return nested.code.toLowerCase()
      if (typeof nested.message === 'string') return nested.message.toLowerCase()
      if (typeof nested.error === 'string') return nested.error.toLowerCase()
    }
  }
  return ''
}

function classifyGeoError(status: number, j: GeoErrorBody | null): GeoErrorCode {
  const code = bodyCode(j)
  if (/(empty|no[_-]?data|no[_-]?result|暂无|没有.*数据)/i.test(code)) return 'empty'
  if (/(not[_-]?configured|config_required|setup_required|未配置|需要配置)/i.test(code)) {
    return 'not-configured'
  }
  if (status === 401 || status === 403 || /forbidden|unauthori[sz]ed|permission|access_denied/i.test(code)) return 'forbidden'
  if (status === 404 || /not[_-]?found|missing/i.test(code)) return 'not-found'
  if (status >= 500 || /upstream|timeout|gateway|service[_-]?unavailable/i.test(code)) return 'upstream'
  return 'contract'
}

/** 将 HTTP 状态和后端错误体映射为稳定的产品错误分类，供卡片按分类决定动作。 */
export const geoErrorCode = classifyGeoError

/** 从 BFF / Nest / :3002 错误体抽出可读文案（避免把 HTTP 状态短语当原因） */
export function geoErrorMessage(
  status: number,
  j: GeoErrorBody | null,
): string {
  const code = classifyGeoError(status, j)
  // 已知分类使用稳定的人话，避免把 no_configured_data 等机器值直接展示给用户。
  if (code !== 'contract' || (!j?.message && !j?.error && !j?.detail)) {
    return {
      empty: '暂无可用数据，请先完成配置或运行一次监测。',
      'not-configured': '还没有完成 GEO 配置，请先去配置。',
      forbidden: '当前账号没有权限执行此操作。',
      'not-found': '找不到请求的 GEO 资源，可能已被删除。',
      upstream: 'GEO 服务暂时不可用，请稍后重试。',
      contract: 'GEO 服务返回的数据格式不完整，请重试；若持续出现请联系管理员。',
    }[code]
  }
  const nestMsg = j?.message
  if (nestMsg && typeof nestMsg === 'object' && typeof (nestMsg as { error?: unknown }).error === 'string') {
    return (nestMsg as { error: string }).error
  }
  if (typeof nestMsg === 'string' && nestMsg && !NEST_GENERIC.test(nestMsg)) {
    return nestMsg
  }
  const err = j?.error
  if (err && typeof err === 'object' && typeof (err as { message?: unknown }).message === 'string') {
    return (err as { message: string }).message
  }
  if (typeof err === 'string' && err && !NEST_GENERIC.test(err)) {
    return err
  }
  if (typeof j?.detail === 'string' && j.detail) return j.detail
  return {
    empty: '暂无可用数据，请先完成配置或运行一次监测。',
    'not-configured': '还没有完成 GEO 配置，请先去配置。',
    forbidden: '当前账号没有权限执行此操作。',
    'not-found': '找不到请求的 GEO 资源，可能已被删除。',
    upstream: 'GEO 服务暂时不可用，请稍后重试。',
    contract: 'GEO 服务返回的数据格式不完整，请重试；若持续出现请联系管理员。',
  }[code]
}

function geoFail(status: number, j: GeoErrorBody | null): never {
  if (status === 401) onProductSessionExpired?.()
  const data = j && typeof j === 'object' ? j : null
  const code = classifyGeoError(status, data)
  const jobId = typeof data?.job_id === 'string' ? data.job_id : typeof data?.jobId === 'string' ? data.jobId : undefined
  const jobStatus = typeof data?.status === 'string' ? data.status : undefined
  throw new GeoApiError(geoErrorMessage(status, data), { code, status, jobId, jobStatus })
}

/** 长任务响应的最小公共形状。调用方可继续轮询既有 status 接口，不会丢掉任务标识。 */
export interface GeoJobResult {
  job_id?: string
  status?: string
  message?: string
  progress?: number
}

export function geoJobInfo(value: unknown): Pick<GeoJobResult, 'job_id' | 'status' | 'progress'> | null {
  if (!value || typeof value !== 'object') return null
  const row = value as Record<string, unknown>
  const job_id = typeof row.job_id === 'string' ? row.job_id : typeof row.jobId === 'string' ? row.jobId : undefined
  const status = typeof row.status === 'string' ? row.status : undefined
  const progress = typeof row.progress === 'number' ? row.progress : typeof row.overall_pct === 'number' ? row.overall_pct : undefined
  return job_id || status || progress !== undefined ? { job_id, status, progress } : null
}

export async function geoGet<T>(path: string): Promise<T> {
  const r = await fetch(`${geoApiBase}${path}`, { headers: geoHeaders() })
  const j = await r.json().catch(() => null)
  if (!r.ok || !j?.ok) geoFail(r.status, j)
  return j.data as T
}

export async function geoPost<T>(path: string, body?: unknown): Promise<T> {
  const r = await fetch(`${geoApiBase}${path}`, {
    method: 'POST',
    headers: geoHeaders(),
    body: body === undefined ? undefined : JSON.stringify(body),
  })
  const j = await r.json().catch(() => null)
  if (!r.ok || !j?.ok) geoFail(r.status, j)
  return j.data as T
}

export async function geoDelete<T>(path: string): Promise<T> {
  const r = await fetch(`${geoApiBase}${path}`, { method: 'DELETE', headers: geoHeaders() })
  const j = await r.json().catch(() => null)
  if (!r.ok || !j?.ok) geoFail(r.status, j)
  return j.data as T
}

export async function geoPatch<T>(path: string, body?: unknown): Promise<T> {
  const r = await fetch(`${geoApiBase}${path}`, {
    method: 'PATCH',
    headers: geoHeaders(),
    body: body === undefined ? undefined : JSON.stringify(body),
  })
  const j = await r.json().catch(() => null)
  if (!r.ok || !j?.ok) geoFail(r.status, j)
  return j.data as T
}

/**
 * 下载二进制产物（周期报告 PDF）：走同一个 geoApiBase、同一张会话票。
 *
 * 为什么要看 content-type 而不是只看状态码：老 v1 的 PDF 路由在「暂无报告」时
 * 是 **HTTP 200 + JSON** `{ok:false,error}`。只信状态码就会把那段 JSON 当成分存成
 * `.pdf`，用户拿到一个打不开的文件还以为是报告。不是 `application/pdf` 就不是产物，
 * 如实把原因说出来。
 */
export async function geoDownload(path: string): Promise<Blob> {
  const r = await fetch(`${geoApiBase}${path}`, { headers: geoHeaders() })
  const contentType = r.headers.get('content-type') ?? ''
  if (r.ok && contentType.toLowerCase().includes('application/pdf')) {
    return r.blob()
  }
  const j = await r.json().catch(() => null)
  if (r.status === 401) onProductSessionExpired?.()
  if (j?.error || j?.message || j?.detail) geoFail(r.status, j)
  throw new Error(
    `GEO 没有返回可下载的文件（HTTP ${r.status}，content-type=${contentType || '无'}）`,
  )
}

/** 下载由 GEO 生成的非 PDF 文件（例如企业资料 Word）。 */
export async function geoDownloadFile(path: string): Promise<Blob> {
  const r = await fetch(`${geoApiBase}${path}`, { headers: geoHeaders() })
  const contentType = r.headers.get('content-type') ?? ''
  if (r.ok && !contentType.toLowerCase().includes('application/json')) return r.blob()
  const j = await r.json().catch(() => null)
  if (r.status === 401) onProductSessionExpired?.()
  if (j?.error || j?.message || j?.detail) geoFail(r.status, j)
  throw new Error(`GEO 没有返回可下载的文件（HTTP ${r.status}）`)
}

/** PUT（素材更新/发布打点等，S4） */
export async function geoPut<T>(path: string, body?: unknown): Promise<T> {
  const r = await fetch(`${geoApiBase}${path}`, {
    method: 'PUT',
    headers: geoHeaders(),
    body: body === undefined ? undefined : JSON.stringify(body),
  })
  const j = await r.json().catch(() => null)
  if (!r.ok || !j?.ok) geoFail(r.status, j)
  return j.data as T
}

/**
 * 文件上传（multipart）。只送 file 本身：`Content-Type` 必须由浏览器带着
 * boundary 自己生成，手写一个 `application/json` 会让后端解析不出任何字段。
 *
 * 老 v1 的上传 handler 在「文件太大 / 类型不支持 / 提不出文本」时回的是
 * **HTTP 200 + `ok:true` 里带 `data.error`**（见 app/core/envelope.py 的 `ok()`），
 * 所以调用方必须读 `data.error`，不能只看 HTTP 成功。
 */
export async function geoUpload<T>(path: string, file: File, field = 'file'): Promise<T> {
  const form = new FormData()
  form.append(field, file)
  const headers = geoHeaders()
  delete headers['Content-Type']
  const r = await fetch(`${geoApiBase}${path}`, { method: 'POST', headers, body: form })
  const j = await r.json().catch(() => null)
  if (!r.ok || !j?.ok) geoFail(r.status, j)
  return j.data as T
}

// ── 类型（字段名来自 :3002 OpenAPI 实测返回） ──────────────────────────────

export interface GeoStatsOverview {
  knowledge: { materials: number; text_blocks: number; bytes: number }
  knowledge_objects?: { empty: boolean | null; entities?: number | null; error?: string | null }
  links: { total: number; indexed: number; failed: number; pending: number; unknown: number }
  monitor: { runs: number; mentioned: number; avg_score: number }
  // total = 这个部署登记了几个模型；answered = 最近一次监测里几个引擎答上来了。
  // 后者不再由产品猜「谁配了 key」——凭据在企业部署手里，猜不出来也不该猜。
  engines: { total: number; answered: number }
}

export interface GeoDistillOverview {
  funnel: Array<{ stage: string; question_count: number; judged_count: number; coverage_pct: number | null }>
  ai_judgment: { stage: string; coverage_pct: number; reason: string; samples: string[] }
  open_gaps_count: number
}

export interface GeoMonitorOverview {
  scope?: { monitor_id?: string | null; scope_required?: boolean; citations_attribution_available?: boolean; identity_status?: 'confirmed' | 'unconfirmed' | null; identity_note?: string | null }
  recommend: { value: number | null; delta: number | null }
  rank: { value: number | null; delta: number | null }
  citations_count: number
  cite_rate: number | null
  published_count: number
  cited_count: number
  latest_batch_at: string | null
  platforms: Record<string, Array<{ ts: string; recommend_pct: number; mentioned: number; configured: number }>>
}

export interface GeoQuestion {
  id: string
  question: string
  keyword: string
  intent: string
  customer_stage: string
  priority: number
  related_entities: string[]
  source: string
  evidence_level: string
  confidence: number
  validated: boolean
  monitor_count: number
  created_at: string
  status?: string
}

export interface GeoGap {
  question: string
  entity: string
  /** 缺哪类企业信息。模型没答上来时后端留空（以前会退化回问题原文，看着有值其实是废话） */
  missing_information: string | null
  /** 缺口判定依据：fact_triple=按知识库事实三元组；document_text=知识库只给了文档分块 */
  judge_basis?: 'fact_triple' | 'document_text'
  /** 判定时真正命中的问题内容词（可复盘） */
  matched_terms?: string[]
  missing_capabilities?: string[]
  source: string
  retrieval_score: number
  matched_refs: Array<{ score: number; name: string }>
}

export interface GeoPlan {
  id: string
  topic: string
  reason: string
  target_question: string
  recommended_content_type: string
  priority: number
  gap_id: string
  source_object: string
  source_type: string
  source: string
  // 内容计划 V1（2026-08-19）：48 认知子项压力算法新增字段
  state?: string          // 待生产 / 待补知识 / 已发布
  status?: string         // planned / knowledge_required / published
  subitem?: string
  subitem_name?: string
  category?: string
  subitem_pressure?: number
  covered_questions?: number
  // 发布登记（Owner 2026-09-21）：发布链接与时间
  published_url?: string
  published_at?: string
}

export interface GeoMonitorItem {
  monitor_id: string
  type: string
  // city：所在地（2026-09-23）——探针按它问「成都本地的家居家具公司有哪些？」
  config_json: { company?: string; aliases?: string[]; product?: string | string[]; industry?: string; city?: string; tier?: string }
  entity: string
  query_count: number
  status: string
  created_time: string
  updated_time: string
  run_result?: {
    state: 'success' | 'failed' | 'never'
    label: string
    last_run_at?: string | null
    answered: number
    failed: number
  }
}

export interface GeoTasks {
  tasks: Array<{
    task_id: string
    name: string
    schedule: string
    status: string
    item_ids: string[]
    created_time: string
    updated_time: string
    id: string
    item_count: number
    last_run_at: string | null
  }>
  total: number
}

export interface GeoCognitionProfile {
  dims: Array<{ key: string; label: string; words: string[]; mention_rate: number; gap_level: string }>
}

export interface GeoMaterial {
  title: string
  content: string
  material_id?: string
  id?: string
  source?: string
  created_at?: string
  published_url?: string // S4 打点：已发布 URL
  /** 上传/新建时切好的段数（存进 GEO 自己的库；0 = 没切块或正文为空） */
  chunks?: number
  /** 原文件名（上传的资料才有） */
  file_name?: string
  /** 来源类型：file（上传文件）/ text（手写）/ generated（生成）/ faq / url */
  source_type?: string
  /** 正文长度（文件管理器显示「多大」用；列表接口才有） */
  chars?: number
  /** 检索命中定位到的那一段的片段（素材检索接口返回；列表接口没有） */
  snippet?: string
  /** 命中在第几段（0 起；没切块或没命中为 null） */
  chunk_ordinal?: number | null
  /** 命中那一段的 id（素材 id#序号） */
  chunk_id?: string | null
  /** 草稿保存时记录的来源材料和实际使用片段；老稿可能没有这些字段。 */
  source_material_ids?: string[] | null
  context_sources?: Array<{ kind: string; label: string; items: Array<Record<string, unknown>> }> | null
  claim_check?: {
    status: 'review_required' | 'no_flags' | string
    flags?: Array<{ kind?: string; claim: string; reason: string }>
    notice?: string
  } | null
}

export interface GeoKnowledgeReadiness {
  source: string
  authoritative: boolean
  read_ever: boolean
  snapshot_count: number
  objects_seen: number
  documents_seen: number
  kinds: Record<string, number>
  last_read_at: string | null
  note: string
}

export interface GeoOnboardStatus {
  empty: boolean
  items: number
  questions: number
  /** GEO 自己的素材库（geo_kb）条目数；不是监测对象数 */
  materials?: number
  /** 企业知识库读到的快照概况（GEO 只读知识库，读到的留在自己库里） */
  knowledge?: GeoKnowledgeReadiness
}

export interface GeoDetectResult {
  company: string[]
  aliases: string[]
  products: string[]
  services: string[]
  industry: string
  keywords: string[]
  empty: boolean
  /** 读知识库失败时非空：「读不到」不等于「知识库是空的」 */
  error?: string | null
  /** llm = 模型归类；heuristic = 名称规则兜底（模型未配置时） */
  classification_source?: string | null
  hint?: string | null
}

/** POST /kb-init/scan：从企业知识库扫出来的候选（内测「知识库初始化」） */
export interface GeoKbInitCandidate {
  name: string
  in_profile: boolean
}

export interface GeoKbInitDocument {
  document_id: string
  title: string
  version?: number | string | null
  in_profile: boolean
  /** false = 知识库里**还没发布**（文档列表看不到它），候选来自 GEO 自己读到过的切块快照 */
  listed?: boolean
  /** GEO 台账里读到过几个**不同**的切块（未发布文档靠这个也能被点选） */
  chunks_stored?: number
}

export interface GeoKbInitScan {
  contract: string
  initialized: boolean
  revision: string | null
  last_applied_at: string | null
  existing: {
    companies: string[]
    products: string[]
    documents: Array<{ document_id: string; title: string; version?: number | string | null }>
  }
  candidates: {
    companies: GeoKbInitCandidate[]
    products: GeoKbInitCandidate[]
    documents: GeoKbInitDocument[]
  }
  classification_source?: string | null
  industry?: string | null
  /** 只在 GEO 快照里的文档：知识库未发布、文档读接口 fail-closed，但切块正文已在 GEO 台账 */
  documents_from_snapshot?: Array<{ document_id: string; title: string; chunks: number }>
  /** 上面那种文档存在时的一句话说明；没有则为空串 */
  snapshot_note?: string
  empty: boolean
  /** 知识库里的知识对象条数（空态提示据此说人话：有对象也照样能初始化） */
  objects_in_knowledge?: number
  /** Foundation 按当前登录主体做可见性过滤；GEO 不跨账号展示私有资料 */
  visibility_note?: string
  error?: string | null
  hint?: string | null
}

/** POST /kb-init/apply：这份选择落进 GEO 自己的库（快照）之后的结果 */
export interface GeoKbInitApply {
  contract: string
  first_time: boolean
  added: {
    companies: string[]
    products: string[]
    documents: Array<{ document_id: string; title: string; version?: number | string | null }>
  }
  kept: { companies: number; products: number; documents: number }
  total: { companies: number; products: number; documents: number }
  unknown_documents: string[]
  /** 同步时一并带回来存下的切块数（门开着=权威给的；门关着=GEO 已存快照） */
  chunks_pulled?: Array<{ document_id: string; chunks: number; truncated?: boolean }>
  chunks_total?: number
  /** 翻页到上限还有没读完的文档 id —— 这些只是「带回来的一部分」 */
  chunks_truncated?: string[]
  recorded: boolean
  revision: string | null
  read_count?: number | null
  /** 这次一个都没勾选（Owner 2026-09-22：都可以不选，照样初始化工作空间） */
  selection_empty?: boolean
  /** 空选择时顺带带回 GEO 自己柜子的企业知识：对象 / 正式事实 / 关系各几条 */
  captured?: { objects: number; facts: number; relations: number; error: string | null } | null
  note: string
}

/**
 * GET /enterprise-profile/overview：企业资料体检总览（规则估算，非 LLM）。
 * total_items = 48 子项 + 合并进来的自定义子项；overall_coverage_pct 为 null 表示问题池还空着，
 * 「算不出来」不等于 0。
 */
export interface GeoProfileOverview {
  overall_coverage_pct: number | null
  total_items: number
  enough_count: number
  partial_count: number
  too_little_count: number
  not_ready_count?: number
  data_status?: {
    questions_count?: number
    knowledge_entities_count?: number
    knowledge_facts_count?: number
    semantic_linked_count?: number
    relations_count?: number
    knowledge_ready?: boolean
  }
  note: string
}

/** 单子项档位：足够 / 部分 / 太少；related_state=none 表示问题池还没覆盖到它 */
export interface GeoProfileItemBrief {
  id: string
  name: string
  level: string
  related_state: string
  coverage_pct: number | null
  related_count: number
}

/** GET /enterprise-profile/categories：8 大类大纲（左树数据） */
export interface GeoProfileCategory {
  category: string
  name: string
  items: GeoProfileItemBrief[]
}

export interface GeoDiscoverResult {
  competitors: Array<{
    name: string
    company?: string
    reason?: string
    /** 哪些模型提到了它（Owner 2026-09-21：问「这几个 AI」，谁答了要如实说） */
    mentioned_by?: string[]
    /** 它在哪几组问题里出现：行业 / 产品 / 服务 */
    asked?: string[]
  }>
  empty?: boolean
  hint?: string | null
  /** 城市从哪来：user=用户填的所在地；company_name=从公司名抠的；none=没有（问「本地」） */
  city?: string
  city_source?: 'user' | 'company_name' | 'none'
  /** 这次实际问了哪几句 */
  questions?: string[]
  engines_total?: number
  engines_answered?: number
  engines_used?: string[]
  not_answered?: string[]
}

/**
 * POST /battle：同一个问题拿去问部署里每一个已登记引擎，可多轮辩论，最后由裁判模型
 * 点评。引擎是谁、有几个，由企业部署决定（GEO 不写死 6 个、也不持凭据）；这个部署
 * 一个都没登记时后端明确回 `no_engines_configured`，不假装打过。
 */
export interface GeoBattleResult {
  question: string
  scope?: { mode: 'selected' | 'all' | 'unspecified'; monitor_id: string | null; name: string | null }
  rounds: Array<{
    round: number
    results: Array<{ engine_id: string; engine_name: string; answer: string }>
  }>
  judge: string | null
  // judge=true 但裁判模型没配上：如实说跳过了，不把「没点评」写成「点评了没意见」。
  judge_skipped: boolean
}

export interface GeoCreateResult {
  created: Array<{ monitor_id: string; entity?: string; type?: string }>
}

export interface GeoRunResult {
  status: string
  progress?: Array<{ monitor_id: string; status: string }>
}

/** GET /onboard/run-status：监测/蒸馏运行进度 */
export interface GeoRunStatus {
  running: boolean
  phase: string
  done: number
  total: number
  error: string | null
  started_at: string | null
  finished: boolean
  overall_pct?: number
  parse?: { succeeded: number; failed: number; running: number; total: number; queue_size: number } | null
  summary: {
    total_questions: number
    answered_questions: number
    mentioned_questions: number
    coverage_pct: number
    score: number
    mentioned: number
    not_mentioned: number
    weak_questions: string[]
  } | null
  distill: unknown
  intelligence: { evidence: number; succeeded: number; failed: number; pending: number; mentions: number } | null
}

export interface GeoDistillResult {
  status: string
  steps?: Array<{ step: string; status: string; detail?: string }>
  stats?: { questions: number; gaps: number; plans: number }
}
